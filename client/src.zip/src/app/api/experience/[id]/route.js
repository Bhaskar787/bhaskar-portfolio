import { NextResponse } from 'next/server';
import connectDB from "@/lib/db";
import Experience from '@/models/Experience';

// GET a single experience
export async function GET(request, { params }) {
  try {
    await connectDB();
    const { id } = await params;
    const exp = await Experience.findById(id);
    if (!exp) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json(exp);
  } catch (error) {
    return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
  }
}

// PUT (Edit) Experience — JSON body
export async function PUT(request, { params }) {
  try {
    await connectDB();
    const { id } = await params;
    const body = await request.json();
    const { title, duration, description, image } = body;

    const updatedExp = await Experience.findByIdAndUpdate(
      id,
      { title, duration, description, image },
      { new: true, runValidators: true }
    );

    if (!updatedExp) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    return NextResponse.json(updatedExp);
  } catch (error) {
    console.error("Experience PUT error:", error);
    return NextResponse.json({ error: "Update failed" }, { status: 500 });
  }
}

// DELETE Experience
export async function DELETE(request, { params }) {
  try {
    await connectDB();
    const { id } = await params;
    const exp = await Experience.findById(id);

    if (!exp) return NextResponse.json({ error: "Not found" }, { status: 404 });

    await Experience.findByIdAndDelete(id);
    return NextResponse.json({ message: "Deleted successfully" });
  } catch (error) {
    return NextResponse.json({ error: "Delete failed" }, { status: 500 });
  }
}
